<template>
    <div class="page">
        <h2 class="title">📋 美食店铺列表</h2>

        <div v-if="cats.length === 0" class="empty-tip">
            <p>还没有店铺，快去添加吧！</p>
        </div>

        <div class="cat-grid">
            <div v-for="cat in cats" :key="cat.cat_id" class="cat-card">
                <div class="cat-avatar">
                    <img v-if="cat.image_path"
                         :src="'http://localhost:3000/uploads/' + cat.image_path"
                         class="cat-photo"
                         alt="店铺照片"
                         @error="handleImageError(cat)" />
                    <span v-else class="default-avatar">🍽️</span>
                </div>
                <div class="cat-info">
                    <h3>{{ cat.nickname }}</h3>
                    <p class="status">
                        状态：
                        <span :class="getStatusClass(cat.health_status)">
                            {{ cat.health_status || '营业中' }}
                        </span>
                    </p>
                    <p class="location">
                        📍 {{ cat.latitude.toFixed(3) }}, {{ cat.longitude.toFixed(3) }}
                    </p>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
    import { ref, onMounted } from 'vue'

    const cats = ref([])

    onMounted(() => {
        fetch('http://localhost:3000/api/cats')
            .then(response => response.json())
            .then(res => {
                if (res.status === 'success') {
                    cats.value = res.data;
                }
            })
            .catch(err => console.error('获取数据失败:', err))
    })

    const getStatusClass = (status) => {
        if (status === '营业中' || status === '推荐中') return 'text-green'
        if (status === '已打烊') return 'text-red'
        return 'text-yellow'
    }

    const handleImageError = (cat) => {
        cat.image_path = null
    }
</script>

<style scoped>
    .page {
        padding: 20px;
        height: calc(100vh - 60px);
        overflow-y: auto;
        background-color: #f9fafb;
    }

    .title {
        text-align: center;
        color: #333;
        margin-bottom: 20px;
    }

    .empty-tip {
        text-align: center;
        color: #888;
        margin-top: 50px;
    }

    .cat-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 15px;
        padding-bottom: 20px;
    }

    .cat-card {
        background: white;
        border-radius: 12px;
        padding: 15px;
        display: flex;
        align-items: center;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        transition: transform 0.2s;
    }

        .cat-card:hover {
            transform: translateY(-2px);
        }

    .cat-avatar {
        width: 70px;
        height: 70px;
        flex-shrink: 0;
        margin-right: 15px;
        border-radius: 50%;
        background: #f3f4f6;
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }

    .cat-photo {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .default-avatar {
        font-size: 36px;
        line-height: 1;
    }

    .cat-info h3 {
        margin: 0 0 5px 0;
        color: #111;
    }

    .cat-info p {
        margin: 3px 0;
        font-size: 14px;
        color: #666;
    }

    .text-green {
        color: #22c55e;
        font-weight: bold;
    }

    .text-red {
        color: #ef4444;
        font-weight: bold;
    }

    .text-yellow {
        color: #eab308;
        font-weight: bold;
    }
</style>