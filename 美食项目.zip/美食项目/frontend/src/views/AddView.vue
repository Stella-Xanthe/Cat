<template>
    <div class="page">
        <h2>➕ 新增美食店铺</h2>

        <form @submit.prevent="submitCat" class="add-form">

            <label>店铺名称：</label>
            <input v-model="formData.nickname" type="text" required placeholder="例如：一食堂" />

            <label>招牌菜 / 简介：</label>
            <input v-model="formData.appearance" type="text" placeholder="例如：麻辣香锅、小炒" />

            <label>营业状态：</label>
            <select v-model="formData.health_status">
                <option value="营业中">🟢 营业中</option>
                <option value="已打烊">🔴 已打烊</option>
                <option value="暂停营业">🟡 暂停营业</option>
                <option value="推荐中">⭐ 推荐中</option>
            </select>

            <label>是否推荐：</label>
            <select v-model="formData.is_sterilized">
                <option :value="0">❌ 未推荐</option>
                <option :value="1">⭐ 推荐</option>
            </select>

            <label>推荐菜品：</label>
            <input v-model="formData.personality" type="text" placeholder="例如：推荐红烧肉" />

            <label>店铺位置 (纬度 Latitude)：</label>
            <input v-model="formData.latitude" type="number" step="0.000001" required />

            <label>店铺位置 (经度 Longitude)：</label>
            <input v-model="formData.longitude" type="number" step="0.000001" required />

            <label>店铺照片：</label>
            <input type="file" @change="handleFileUpload" accept="image/*" />
            <small style="color:#999; margin-top:-10px;">支持 jpg / png 格式，建议小于 5MB</small>

            <button type="submit" class="submit-btn">💾 保存并上传</button>
        </form>
    </div>
</template>

<script setup>
    import { ref, onMounted } from 'vue'
    import { useRouter, useRoute } from 'vue-router'

    const router = useRouter()
    const route = useRoute()

    const formData = ref({
        nickname: '',
        appearance: '',
        health_status: '营业中',
        is_sterilized: 0,
        personality: '',
        latitude: 31.9050,
        longitude: 118.7850,
        imageFile: null
    })

    onMounted(() => {
        if (route.query.lat && route.query.lng) {
            formData.value.latitude = parseFloat(route.query.lat)
            formData.value.longitude = parseFloat(route.query.lng)
        }
    })

    const handleFileUpload = (event) => {
        const file = event.target.files[0]
        if (file) {
            formData.value.imageFile = file
        }
    }

    const submitCat = () => {
        const fd = new FormData()
        fd.append('nickname', formData.value.nickname)
        fd.append('appearance', formData.value.appearance || '')
        fd.append('health_status', formData.value.health_status)
        fd.append('is_sterilized', formData.value.is_sterilized)
        fd.append('personality', formData.value.personality || '')
        fd.append('latitude', formData.value.latitude)
        fd.append('longitude', formData.value.longitude)
        fd.append('discovery_time', new Date().toISOString())

        if (formData.value.imageFile) {
            fd.append('image', formData.value.imageFile)
        }

        fetch('http://localhost:3000/api/cats', {
            method: 'POST',
            body: fd
        })
            .then(response => response.json())
            .then(res => {
                if (res.status === 'success') {
                    alert('🎉 店铺添加成功！')
                    router.push('/')
                } else {
                    alert('保存失败：' + res.message)
                }
            })
            .catch(err => {
                console.error(err)
                alert('网络请求失败，请检查后端是否运行')
            })
    }
</script>

<style scoped>
    .page {
        padding: 20px;
        max-width: 400px;
        margin: 0 auto;
    }

    .add-form {
        display: flex;
        flex-direction: column;
        gap: 12px;
        margin-top: 16px;
    }

    label {
        font-weight: bold;
        color: #333;
        margin-bottom: 2px;
    }

    input, select {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
    }

    small {
        font-size: 12px;
        color: #999;
    }

    .submit-btn {
        margin-top: 16px;
        padding: 14px;
        background-color: #3b82f6;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: 0.2s;
    }

        .submit-btn:hover {
            background-color: #2563eb;
        }
</style>