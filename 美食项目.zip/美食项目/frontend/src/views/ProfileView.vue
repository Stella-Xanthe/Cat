<template>
    <div class="page">
        <h2 class="title">👤 同学，你好！</h2>
        <p class="subtitle">🍜 校园美食探索者</p>

        <div class="stats-grid">
            <div class="stat-card">
                <span class="stat-number">{{ myCats.length }}</span>
                <span class="stat-label">我添加的店铺</span>
            </div>
            <div class="stat-card">
                <span class="stat-number">{{ myFeeds.length }}</span>
                <span class="stat-label">我的探店记录</span>
            </div>
        </div>

        <h3 class="section-title">📋 我添加的店铺</h3>
        <div v-if="myCats.length === 0" class="empty-tip">
            还没有添加店铺，去发现美食吧！
        </div>
        <div v-else class="cat-list">
            <div v-for="cat in myCats" :key="cat.cat_id" class="list-item">
                <div class="item-icon">🍽️</div>
                <div class="item-info">
                    <h4>{{ cat.nickname }}</h4>
                    <p>{{ cat.appearance || '暂无简介' }}</p>
                    <span class="status-tag" :class="getStatusClass(cat.health_status)">
                        {{ cat.health_status || '营业中' }}
                    </span>
                </div>
            </div>
        </div>

        <h3 class="section-title">📝 我的探店记录</h3>
        <div v-if="myFeeds.length === 0" class="empty-tip">
            还没有探店记录，去探索校园美食吧！
        </div>
        <div v-else class="cat-list">
            <div v-for="feed in myFeeds" :key="feed.id" class="list-item">
                <div class="item-icon">📍</div>
                <div class="item-info">
                    <h4>{{ feed.name }}</h4>
                    <p>{{ feed.location }}</p>
                    <span class="date-tag">{{ feed.date }}</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
    import { ref, onMounted } from 'vue'

    const myCats = ref([
        // 示例数据，实际从后端获取当前用户添加的店铺
        { cat_id: 1, nickname: '一食堂', appearance: '麻辣香锅、小炒', health_status: '营业中' },
        { cat_id: 2, nickname: '图书馆咖啡', appearance: '拿铁、美式', health_status: '营业中' }
    ])

    const myFeeds = ref([
        // 示例数据，实际从后端获取
        { id: 1, name: '一食堂', location: '图书馆门口', date: '2024-04-10' },
        { id: 2, name: '二食堂', location: '三食堂后巷', date: '2024-04-15' }
    ])

    const getStatusClass = (status) => {
        if (status === '营业中' || status === '推荐中') return 'status-open'
        if (status === '已打烊') return 'status-closed'
        return 'status-paused'
    }

    onMounted(() => {
        // 实际从后端获取当前用户的数据
        // fetch('http://localhost:3000/api/my-cats?user_id=xxx')
    })
</script>

<style scoped>
    .page {
        padding: 20px;
        max-height: calc(100vh - 60px);
        overflow-y: auto;
        background-color: #f9fafb;
    }

    .title {
        text-align: center;
        color: #333;
        margin-bottom: 0;
    }

    .subtitle {
        text-align: center;
        color: #888;
        margin-top: 4px;
        font-size: 14px;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
        margin: 16px 0 24px 0;
    }

    .stat-card {
        background: white;
        border-radius: 12px;
        padding: 16px;
        text-align: center;
        box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    }

    .stat-number {
        display: block;
        font-size: 32px;
        font-weight: bold;
        color: #f59e0b;
    }

    .stat-label {
        display: block;
        font-size: 12px;
        color: #888;
        margin-top: 4px;
    }

    .section-title {
        color: #333;
        font-size: 16px;
        margin: 16px 0 10px 0;
    }

    .empty-tip {
        text-align: center;
        color: #aaa;
        padding: 20px 0;
        font-size: 14px;
    }

    .cat-list {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .list-item {
        background: white;
        border-radius: 12px;
        padding: 12px 16px;
        display: flex;
        align-items: center;
        gap: 14px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }

    .item-icon {
        font-size: 28px;
        width: 44px;
        text-align: center;
    }

    .item-info {
        flex: 1;
    }

        .item-info h4 {
            margin: 0 0 2px 0;
            font-size: 16px;
            color: #333;
        }

        .item-info p {
            margin: 0 0 4px 0;
            font-size: 13px;
            color: #888;
        }

    .status-tag, .date-tag {
        font-size: 12px;
        padding: 2px 10px;
        border-radius: 12px;
        background: #f3f4f6;
        color: #666;
    }

    .status-open {
        background: #d1fae5;
        color: #065f46;
    }

    .status-closed {
        background: #fee2e2;
        color: #991b1b;
    }

    .status-paused {
        background: #fef3c7;
        color: #92400e;
    }
</style>