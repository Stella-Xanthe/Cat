<template>
    <div id="app">
        <!-- 页面内容区域 -->
        <router-view />

        <!-- 底部导航栏 -->
        <div class="bottom-nav">
            <router-link to="/" class="nav-item">
                <span class="nav-icon">📍</span>
                <span class="nav-label">美食</span>
            </router-link>
            <router-link to="/archive" class="nav-item">
                <span class="nav-icon">📋</span>
                <span class="nav-label">店铺</span>
            </router-link>
            <router-link to="/add" class="nav-item">
                <span class="nav-icon">➕</span>
                <span class="nav-label">新增</span>
            </router-link>
            <router-link to="/profile" class="nav-item">
                <span class="nav-icon">👤</span>
                <span class="nav-label">我的</span>
            </router-link>
        </div>
    </div>
</template>

<script setup>
    // 这里可以放全局逻辑
</script>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        background: #f5f6fa;
    }

    #app {
        max-width: 480px;
        margin: 0 auto;
        background: #fff;
        min-height: 100vh;
        position: relative;
        padding-bottom: 70px; /* 留出底部导航栏的空间 */
    }

    /* ========== 底部导航栏样式 ========== */
    .bottom-nav {
        position: fixed;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        max-width: 480px;
        width: 100%;
        background: white;
        display: flex;
        justify-content: space-around;
        align-items: center;
        padding: 8px 0 12px 0;
        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.08);
        border-top: 1px solid #eee;
        z-index: 999;
    }

    .nav-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-decoration: none;
        color: #999;
        font-size: 12px;
        transition: color 0.2s;
        padding: 4px 12px;
        border-radius: 8px;
    }

        .nav-item .nav-icon {
            font-size: 24px;
            line-height: 1.2;
        }

        .nav-item .nav-label {
            font-size: 11px;
            margin-top: 2px;
        }

    /* 激活状态（当前页面高亮） */
    .router-link-active {
        color: #f59e0b;
        font-weight: 600;
    }
</style>