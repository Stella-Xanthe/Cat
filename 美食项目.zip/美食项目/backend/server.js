const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');
const multer = require('multer');
const fs = require('fs');

const app = express();

// 中间件配置
app.use(cors());
app.use(express.json());

// ============ 图片上传配置 ============
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueName = Date.now() + '-' + file.originalname;
        cb(null, uniqueName);
    }
});
const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }  // 限制 5MB
});

// 静态资源托管：让前端能访问图片
app.use('/uploads', express.static(uploadDir));

// ============ 数据库连接 ============
const dbPath = path.join(__dirname, 'cat_map.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('数据库连接失败:', err.message);
    } else {
        console.log('✅ 成功连接到 SQLite 数据库 cat_map.db');

        // 建表语句：去掉了 CHECK 约束，默认 health_status 为 '营业中'
        const createTableSql = `
            CREATE TABLE IF NOT EXISTS cats (
                cat_id INTEGER PRIMARY KEY AUTOINCREMENT,
                nickname TEXT NOT NULL,
                discovery_time DATETIME,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                appearance TEXT,
                health_status TEXT DEFAULT '营业中',
                is_sterilized INTEGER DEFAULT 0,
                personality TEXT,
                image_path TEXT
            )
        `;
        db.run(createTableSql, (err) => {
            if (err) {
                console.error('创建数据表失败:', err.message);
            } else {
                console.log('✅ cats 数据表已准备就绪！');
            }
        });
    }
});

// ============ API 接口 ============

// 测试接口
app.get('/api/status', (req, res) => {
    res.json({ status: 'success', message: '后端服务器运行正常！' });
});

// 获取所有猫咪
app.get('/api/cats', (req, res) => {
    db.all('SELECT * FROM cats', [], (err, rows) => {
        if (err) {
            res.status(500).json({ status: 'error', message: err.message });
            return;
        }
        res.json({ status: 'success', data: rows });
    });
});

// 新增猫咪（支持图片上传）
app.post('/api/cats', upload.single('image'), (req, res) => {
    const {
        nickname,
        discovery_time,
        latitude,
        longitude,
        appearance,
        health_status,
        is_sterilized,
        personality
    } = req.body;

    const image_path = req.file ? req.file.filename : '';

    const sql = `INSERT INTO cats (
        nickname, discovery_time, latitude, longitude, 
        appearance, health_status, is_sterilized, personality, image_path
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    db.run(sql, [
        nickname,
        discovery_time || new Date().toISOString(),
        latitude,
        longitude,
        appearance || '',
        health_status || '营业中',   // 默认改为营业中
        is_sterilized || 0,
        personality || '',
        image_path
    ], function (err) {
        if (err) {
            console.error('保存猫咪失败:', err);
            res.status(500).json({ status: 'error', message: err.message });
            return;
        }
        res.json({
            status: 'success',
            message: '建档成功！',
            cat_id: this.lastID
        });
    });
});

// 数据统计接口（适配美食主题，统计 health_status 分布）
app.get('/api/stats', (req, res) => {
    let total = 0;
    db.get("SELECT COUNT(*) as count FROM cats", (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        total = row.count;

        db.all("SELECT health_status, COUNT(*) as count FROM cats GROUP BY health_status", (err, healthRows) => {
            if (err) return res.status(500).json({ error: err.message });

            // is_sterilized 在这里可视为“是否推荐”，但我们可以保留或改为其他含义
            db.get("SELECT SUM(is_sterilized) as sterilized, COUNT(*) - SUM(is_sterilized) as unsterilized FROM cats", (err, sterRows) => {
                if (err) return res.status(500).json({ error: err.message });

                res.json({
                    status: 'success',
                    data: {
                        total: total,
                        health_distribution: healthRows,
                        sterilization: {
                            sterilized: sterRows.sterilized || 0,
                            unsterilized: sterRows.unsterilized || 0
                        }
                    }
                });
            });
        });
    });
});

// ============ 启动服务器 ============
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`🚀 后端服务器已启动，正在运行: http://localhost:${PORT}`);
});