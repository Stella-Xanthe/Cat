<template>
    <div id="map-container">
        <div id="map"></div>
    </div>
</template>

<script setup>
    import { onMounted, ref } from 'vue';
    import { useRouter } from 'vue-router';
    import L from 'leaflet';
    import 'leaflet/dist/leaflet.css';

    const router = useRouter();
    const map = ref(null);

    // 状态对应的颜色（用于弹窗标签）
    const getStatusColor = (status) => {
        if (status === '营业中' || status === '推荐中') return '#22c55e'; // 绿色
        if (status === '已打烊') return '#ef4444'; // 红色
        return '#eab308'; // 黄色（暂停营业等）
    };

    // 状态对应的 Emoji
    const getStatusEmoji = (status) => {
        if (status === '营业中' || status === '推荐中') return '🟢';
        if (status === '已打烊') return '🔴';
        return '🟡';
    };

    onMounted(() => {
        // 1. 初始化地图
        map.value = L.map('map').setView([31.910, 118.785], 16);

        // 2. 加载 OpenStreetMap 底图
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19,
        }).addTo(map.value);

        // 3. 加载猫咪/店铺数据
        fetchCats();

        // 4. 长按地图：跳转到新增页面，并自动填入经纬度
        map.value.on('contextmenu', (e) => {
            const { lat, lng } = e.latlng;
            router.push(`/add?lat=${lat}&lng=${lng}`);
        });
    });

    // 获取数据并渲染标记
    const fetchCats = async () => {
        try {
            const response = await fetch('http://localhost:3000/api/cats');
            const res = await response.json();
            if (res.status === 'success') {
                res.data.forEach((cat) => {
                    addMarker(cat);
                });
            } else {
                console.error('数据加载失败:', res.message);
            }
        } catch (err) {
            console.error('网络请求失败:', err);
        }
    };

    // 添加单个标记
    const addMarker = (cat) => {
        // 自定义图标（美食主题）
        const icon = L.divIcon({
            className: 'custom-marker',
            html: `<div style="background: #f59e0b; color: white; border-radius: 50%; width: 36px; height: 36px; display: flex; justify-content: center; align-items: center; font-size: 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.3); border: 2px solid white;">🍽️</div>`,
            iconSize: [36, 36],
            iconAnchor: [18, 36],
            popupAnchor: [0, -36],
        });

        const marker = L.marker([cat.latitude, cat.longitude], { icon }).addTo(map.value);

        // ---------- 构建丰富的弹窗内容 ----------
        const popupContent = `
    <div style="min-width: 220px; max-width: 280px; font-family: -apple-system, sans-serif; padding: 4px 0;">
      <!-- 标题行：名称 + 状态标签 -->
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f0f0f0; padding-bottom: 8px; margin-bottom: 8px;">
        <strong style="font-size: 18px; color: #1f2937;">${cat.nickname}</strong>
        <span style="background: ${getStatusColor(cat.health_status)}; color: white; padding: 2px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; white-space: nowrap;">
          ${getStatusEmoji(cat.health_status)} ${cat.health_status || '营业中'}
        </span>
      </div>

      <!-- 照片区域 -->
      ${cat.image_path ? `
        <img src="http://localhost:3000/uploads/${cat.image_path}"
             style="width: 100%; height: 140px; object-fit: cover; border-radius: 10px; margin-bottom: 10px;"
             onerror="this.style.display='none'" />
      ` : `
        <div style="width: 100%; height: 80px; background: #f3f4f6; border-radius: 10px; display: flex; justify-content: center; align-items: center; color: #9ca3af; font-size: 14px; margin-bottom: 10px;">
          🍽️ 暂无照片
        </div>
      `}

      <!-- 详细信息 -->
      <div style="font-size: 14px; color: #4b5563;">
        <p style="margin: 4px 0; display: flex; align-items: center; gap: 6px;">
          <span style="font-weight: 600; color: #1f2937;">🍜 招牌菜：</span>
          <span>${cat.appearance || '暂无'}</span>
        </p>
        <p style="margin: 4px 0; display: flex; align-items: center; gap: 6px;">
          <span style="font-weight: 600; color: #1f2937;">⭐ 推荐菜：</span>
          <span>${cat.personality || '暂无'}</span>
        </p>
        <p style="margin: 6px 0 0 0; font-size: 11px; color: #9ca3af; border-top: 1px dashed #e5e7eb; padding-top: 6px;">
          📍 ${cat.latitude.toFixed(5)}, ${cat.longitude.toFixed(5)}
        </p>
      </div>
    </div>
  `;

        marker.bindPopup(popupContent, { maxWidth: 300 });
    };
</script>

<style scoped>
    #map-container {
        height: calc(100vh - 60px); /* 减去底部导航栏高度 */
        width: 100%;
        position: relative;
    }

    #map {
        height: 100%;
        width: 100%;
    }

    /* 地图标记的全局样式（避免被 scoped 限制，这里不写 scoped 也可以，但为了保险放在这里） */
    :deep(.leaflet-popup-content-wrapper) {
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
    }

    :deep(.leaflet-popup-content) {
        margin: 12px 16px;
    }
</style>